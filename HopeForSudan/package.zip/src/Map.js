import Header from "./components/header";
import Footer from "./components/footer";
import { useState, useRef } from "react";
import { MapContainer, TileLayer, GeoJSON, Marker, Popup } from "react-leaflet";
import L from "leaflet";
import sudanStates from "./sudan_states.json";
import "bootstrap/dist/css/bootstrap.min.css";

// 🟢 نسب توفر الخدمات
const servicesAvailability = {
  "Khartoum": 90,
  "Gezira": 70,
  "North Darfur": 30,
  "South Darfur": 20,
  "Blue Nile": 15,
  "Red Sea": 80,
  "River Nile": 60,
  "White Nile": 50,
  "Kassala": 40,
  "Northern": 35,
  "North Kordofan": 25,
  "South Kordofan": 20,
  "West Darfur": 10,
  "Central Darfur": 15,
  "East Darfur": 18,
  "West Kordofan": 30,
  "Sennar": 55,
  "Al Qadarif": 45,
};

// 🎨 دالة الألوان
function getColor(percent) {
  return percent > 80 ? "#006400" : // Dark Green
         percent > 60 ? "#32CD32" : // Green
         percent > 40 ? "#FFFF00" : // Yellow
         percent > 20 ? "#FFA500" : // Orange
                        "#8B0000";  // Dark Red
}

// 🎨 استايل الولايات
function styleFactory(feature) {
  const name = feature.properties.name; // اسم الولاية من GeoJSON
  const percent = servicesAvailability[name] || 0;
  return {
    fillColor: getColor(percent),
    weight: 2,
    opacity: 1,
    color: "white",
    fillOpacity: 0.7,
  };
}

// ⚡ أيقونات
const electricityIcon = new L.Icon({
  iconUrl: "https://cdn-icons-png.flaticon.com/512/854/854866.png",
  iconSize: [25, 25],
});
const waterIcon = new L.Icon({
  iconUrl: "https://cdn-icons-png.flaticon.com/512/728/728093.png",
  iconSize: [25, 25],
});

// 📍 بيانات markers
const markersData = [
  { type: "electricity", position: [15.55, 32.53], name: "Khartoum Power Station" },
  { type: "water", position: [14.5, 33.3], name: "Gezira Water Facility" },
  { type: "water", position: [13.6, 25.3], name: "Darfur Water Facility" },
];

export default function MapWithSmoothSidebar() {
  const [showSidebar, setShowSidebar] = useState(false);
  const [showMarkers, setShowMarkers] = useState(true);
  const mapRef = useRef();

  // 🟢 دوال التكبير والتصغير
  const zoomIn = () => {
    const map = mapRef.current;
    if (map) map.setZoom(map.getZoom() + 1);
  };
  const zoomOut = () => {
    const map = mapRef.current;
    if (map) map.setZoom(map.getZoom() - 1);
  };

  return (
    <>
      <Header />

      <div style={{ position: "relative", height: "80vh" }}>
        {/* 📂 Sidebar الكبير */}
        <div className={`sidebar ${showSidebar ? "sidebar-open" : "sidebar-closed"}`}>
          <div className="d-flex justify-content-between align-items-center mb-3">
            <h5 className="text-primary mb-0">⚡ Layers</h5>
            <button
              className="btn btn-sm btn-outline-light"
              onClick={() => setShowSidebar(false)}
            >
              ❌
            </button>
          </div>

          <div className="form-check mb-2">
            <input className="form-check-input" type="checkbox" id="chkElec" defaultChecked />
            <label className="form-check-label ms-2" htmlFor="chkElec">
              <span className="badge bg-primary">Electricity</span>
            </label>
          </div>

          <div className="form-check mb-2">
            <input className="form-check-input" type="checkbox" id="chkWater" />
            <label className="form-check-label ms-2" htmlFor="chkWater">
              <span className="badge bg-info">Water</span>
            </label>
          </div>
        </div>

        {/* 📏 Mini Sidebar */}
        {!showSidebar && (
          <div className="mini-sidebar">
            <button className="btn btn-primary btn-sm" onClick={() => setShowSidebar(true)}>
              ☰
            </button>
            <button className="btn btn-success btn-sm" onClick={zoomIn}>
              ＋
            </button>
            <button className="btn btn-warning btn-sm" onClick={zoomOut}>
              －
            </button>
            <button
              className="btn btn-danger btn-sm"
              onClick={() => setShowMarkers(!showMarkers)}
            >
              {showMarkers ? "👁" : "🚫"}
            </button>
          </div>
        )}

        {/* 🗺️ الخريطة */}
        <MapContainer
          center={[15.5, 32.5]}
          zoom={5}
          style={{ height: "100%", width: "100%" }}
          whenCreated={(mapInstance) => {
            mapRef.current = mapInstance;
          }}
        >
          <TileLayer
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            attribution="&copy; OpenStreetMap contributors"
          />

          {/* 🎨 تلوين الولايات */}
          <GeoJSON data={sudanStates} style={styleFactory} />

          {/* 📍 markers */}
          {showMarkers &&
            markersData.map((marker, idx) => (
              <Marker
                key={idx}
                position={marker.position}
                icon={marker.type === "electricity" ? electricityIcon : waterIcon}
              >
                <Popup>{marker.name}</Popup>
              </Marker>
            ))}
        </MapContainer>
      </div>

      <Footer />
    </>
  );
}

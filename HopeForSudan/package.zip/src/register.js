import { Link } from "react-router-dom";

export default function Register() {
  return (
    <>
      <section
        className="d-flex justify-content-center align-items-center"
        style={{ backgroundColor: "#000216" }}
      >
        <div
          className="login-card p-5 rounded-4 shadow-sm"
          style={{ maxWidth: 400, width: "100%", backgroundColor: "#020423" }}
        >
          <h2 className="text-center mb-4" style={{ fontWeight: "700" }}>
            Register
          </h2>
          <form>
           
            <label
              htmlFor="name"
              className="form-label"
              style={{ fontWeight: "600" }}
            >
              Name
            </label>
            <input
              type="name"
              id="name"
              className="form-control mb-4"
              placeholder="Enter you name"
              required
              style={{
                borderColor: "var(--primary)",
                background: "#000216",
                borderRadius: "12px",
                padding: "12px 15px",
                fontSize: "16px",
                color: "#484c7c",
              }}
            />

             <label
              htmlFor="email"
              className="form-label"
              style={{ fontWeight: "600" }}
            >
              Email Address
            </label>
            <input
              type="email"
              id="email"
              className="form-control mb-4"
              placeholder="example@mail.com"
              required
              style={{
                borderColor: "var(--primary)",
                background: "#000216",
                borderRadius: "12px",
                padding: "12px 15px",
                fontSize: "16px",
                color: "#484c7c",
              }}
            />


            <label
              htmlFor="password"
              className="form-label"
              style={{ fontWeight: "600" }}
            >
              Password
            </label>
            <input
              type="password"
              id="password"
              className="form-control mb-4"
              placeholder="Enter your password"
              required
              style={{
                borderColor: "var(--primary)",
                background: "#000216",
                borderRadius: "12px",
                padding: "12px 15px",
                fontSize: "16px",
                color: "#484c7c",
              }}
            />

            <label
              htmlFor="password"
              className="form-label"
              style={{ fontWeight: "600" }}
            >
              Confirm Password
            </label>
            <input
              type="password"
              id="password"
              className="form-control mb-4"
              placeholder="Confirm your password"
              required
              style={{
                borderColor: "var(--primary)",
                background: "#000216",
                borderRadius: "12px",
                padding: "12px 15px",
                fontSize: "16px",
                color: "#484c7c",
              }}
            />

            <button type="submit" className="btn primary w-100 py-3 fw-bold">
              Sign Up
            </button>
          </form>

          <p className="text-center mt-4">
            Already have an account?{" "}
            <Link
              to="/Login"
              className="text-accent fw-semibold"
              style={{ textDecoration: "none" }}
            >
              Sign in
            </Link>
          </p>
        </div>
      </section>
    </>
  );
}

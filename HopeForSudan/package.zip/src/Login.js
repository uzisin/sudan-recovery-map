import { Link } from "react-router-dom";

export default function Login() {
  return (
    <>
      <section
        className="vh-100 d-flex justify-content-center align-items-center"
        style={{ backgroundColor: "#000216" }}
      >
        <div
          className="login-card p-5 rounded-4 shadow-sm"
          style={{ maxWidth: 400, width: "100%", backgroundColor: "#020423" }}
        >
          <h2 className="text-center mb-4" style={{ fontWeight: "700" }}>
            Log In
          </h2>
          <form>
            <label
              htmlFor="email"
              className="form-label"
              style={{ fontWeight: "600" }}
            >
              Email Address
            </label>
            <input
              type="email"
              id="email"
              className="form-control mb-4"
              placeholder="example@mail.com"
              required
              style={{
                borderColor: "var(--primary)",
                background: "#000216",
                borderRadius: "12px",
                padding: "12px 15px",
                fontSize: "16px",
                color: "#484c7c",
              }}
            />

            <label
              htmlFor="password"
              className="form-label"
              style={{ fontWeight: "600" }}
            >
              Password
            </label>
            <input
              type="password"
              id="password"
              className="form-control mb-4"
              placeholder="Enter your password"
              required
              style={{
                borderColor: "var(--primary)",
                background: "#000216",
                borderRadius: "12px",
                padding: "12px 15px",
                fontSize: "16px",
                color: "#484c7c",
              }}
            />

            <div className="d-flex justify-content-between align-items-center mb-4">
              <div className="form-check">
                <input
                  className="form-check-input"
                  type="checkbox"
                  id="rememberMe"
                  defaultChecked
                  style={{ cursor: "pointer" }}
                />
                <label
                  className="form-check-label color-primary"
                  htmlFor="rememberMe"
                >
                  Remember me
                </label>
              </div>
              <a
                href="#!"
                className="text-primary"
                style={{ textDecoration: "none" }}
              >
                Forgot password?
              </a>
            </div>

            <button type="submit" className="btn primary w-100 py-3 fw-bold">
              Sign In
            </button>
          </form>

          <p className="text-center mt-4">
            Don't have an account?{" "}
            <Link
              to="/register"
              className="text-accent fw-semibold"
              style={{ textDecoration: "none" }}
            >
              Sign Up
            </Link>
          </p>
        </div>
      </section>
    </>
  );
}

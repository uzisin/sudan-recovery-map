from PIL import Image

# Open the image
img = Image.open("test.jpg")

# Display the image
img.show()
